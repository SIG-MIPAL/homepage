// Standalone member-page form: collects profile/education/publications/awards/news + image
// uploads, then zips them (content.json + images/) with JSZip for the member to download and
// send to the admin. The admin imports the zip via "Import zip". No server needed.
(function () {
  'use strict';
  const images = {};        // filename -> File (all uploaded images, keyed by chosen name)
  let profilePhotoRef = ''; // images/<name> for the profile photo

  // ---- helpers ----
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function escAttr(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
  function val(id) { const el = document.getElementById(id); return el ? el.value.trim() : ''; }
  function q(parent, sel) { const el = parent.querySelector(sel); return el ? el.value.trim() : ''; }
  function btn(text, onclick, cls) { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn sm ' + (cls || ''); b.textContent = text; b.onclick = onclick; return b; }
  function setStatus(msg, kind) { const s = document.getElementById('status'); s.textContent = msg; s.className = 'status' + (kind ? ' ' + kind : ''); }
  function slugify(s) { return String(s || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'image'; }

  // Read a picked image file, give it a unique name, store it, show a thumbnail, and report the
  // images/<name> ref back to the caller (which stores it on the relevant content field).
  function pickImage(input, onPicked) {
    const file = input.files && input.files[0];
    if (!file) return;
    let base = slugify(file.name.replace(/\.[^.]+$/, '')) || 'image';
    let ext = (file.name.split('.').pop() || 'png').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (ext === 'jpeg') ext = 'jpg';
    if (!ext) ext = 'png';
    let name = base + '.' + ext, n = 2;
    while (images[name]) name = base + '-' + (n++) + '.' + ext;
    images[name] = file;
    onPicked('images/' + name);
    const thumb = input.parentElement.querySelector('.thumb');
    if (thumb) { thumb.src = URL.createObjectURL(file); thumb.style.display = ''; }
  }

  // ---- repeatable item builders ----
  function addBio(text) {
    const list = document.getElementById('bio-list');
    const row = document.createElement('div');
    row.className = 'sub-row';
    const ta = document.createElement('textarea');
    ta.className = 'in bio-text'; ta.rows = 3; ta.placeholder = 'A paragraph about yourself. HTML allowed.';
    ta.value = text || '';
    row.appendChild(ta);
    row.appendChild(btn('✕', () => row.remove(), 'danger'));
    list.appendChild(row);
  }
  function addLink(label, url) {
    const list = document.getElementById('link-list');
    const row = document.createElement('div');
    row.className = 'sub-row';
    row.innerHTML = '<input class="in link-label" placeholder="Label (e.g. Google Scholar)" value="' + escAttr(label || '') + '">' +
      '<input class="in link-url" placeholder="URL" value="' + escAttr(url || '') + '">';
    row.appendChild(btn('✕', () => row.remove(), 'danger'));
    list.appendChild(row);
  }
  function addNews() {
    const list = document.getElementById('news-list');
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = '<div class="card-head"><span>News</span></div>' +
      '<div class="row"><div class="field tight"><label>Date</label><input class="in n-date" placeholder="2026/07"></div>' +
      '<div class="field"><label>Text</label><input class="in n-text" placeholder="One paper accepted by ..."></div></div>';
    card.querySelector('.card-head').appendChild(btn('✕', () => card.remove(), 'danger'));
    list.appendChild(card);
  }
  function addAward() {
    const list = document.getElementById('award-list');
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = '<div class="card-head"><span>Award</span></div>' +
      '<div class="row"><div class="field tight"><label>Date</label><input class="in aw-date" placeholder="2025"></div>' +
      '<div class="field"><label>Award</label><input class="in aw-text" placeholder="Award name"></div></div>';
    card.querySelector('.card-head').appendChild(btn('✕', () => card.remove(), 'danger'));
    list.appendChild(card);
  }
  function addEducation() {
    const list = document.getElementById('edu-list');
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = '<div class="card-head"><span>Education entry</span></div>' +
      '<div class="row"><div class="field tight"><label>Logo</label><div class="img-field"><input type="file" accept="image/*" class="edu-logo"><img class="thumb" style="display:none"></div></div>' +
      '<div class="field"><label>Institution</label><input class="in edu-inst" placeholder="e.g. Tongji University"></div>' +
      '<div class="field tight"><label>Period</label><input class="in edu-period" placeholder="2023 - Present"></div></div>' +
      '<div class="field"><label>Details</label><div class="edu-details"></div>' +
      '<button type="button" class="btn sm add-btn" onclick="addDetail(this.closest(\'.card\'))">+ Add detail</button></div>';
    const logoInput = card.querySelector('.edu-logo');
    logoInput.onchange = () => pickImage(logoInput, (ref) => { card.dataset.logo = ref; });
    card.querySelector('.card-head').appendChild(btn('✕', () => card.remove(), 'danger'));
    list.appendChild(card);
    addDetail(card);
  }
  function addDetail(card, sel) {
    const list = card.querySelector(sel || '.edu-details');
    const row = document.createElement('div');
    row.className = 'sub-row';
    row.innerHTML = '<input class="in det-text" placeholder="A detail line"><label class="chk"><input type="checkbox" class="det-note"> note</label>';
    row.appendChild(btn('✕', () => row.remove(), 'danger'));
    list.appendChild(row);
  }
  function addExperience() {
    const list = document.getElementById('exp-list');
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = '<div class="card-head"><span>Experience entry</span></div>' +
      '<div class="row"><div class="field tight"><label>Logo</label><div class="img-field"><input type="file" accept="image/*" class="exp-logo"><img class="thumb" style="display:none"></div></div>' +
      '<div class="field"><label>Organization</label><input class="in exp-org" placeholder="e.g. Google Research"></div>' +
      '<div class="field tight"><label>Role</label><input class="in exp-role" placeholder="e.g. Research Intern"></div></div>' +
      '<div class="field tight"><label>Period</label><input class="in exp-period" placeholder="2025 Summer"></div>' +
      '<div class="field"><label>Details</label><div class="exp-details"></div>' +
      '<button type="button" class="btn sm add-btn" onclick="addDetail(this.closest(\'.card\'), \'.exp-details\')">+ Add detail</button></div>';
    const logoInput = card.querySelector('.exp-logo');
    logoInput.onchange = () => pickImage(logoInput, (ref) => { card.dataset.logo = ref; });
    card.querySelector('.card-head').appendChild(btn('✕', () => card.remove(), 'danger'));
    list.appendChild(card);
    addDetail(card, '.exp-details');
  }
  function addPub() {
    const list = document.getElementById('pub-list');
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = '<div class="card-head"><span>Publication</span></div>' +
      '<div class="row"><div class="field tight"><label>Group</label><select class="in pub-group"><option value="journals">Journal</option><option value="conferences" selected>Conference</option></select></div>' +
      '<div class="field tight"><label>ID (short, unique)</label><input class="in pub-id" placeholder="e.g. cpsc"></div></div>' +
      '<div class="field"><label>Title</label><input class="in pub-title" placeholder="Paper title"></div>' +
      '<div class="field"><label>Authors</label><div class="pub-authors"></div>' +
      '<button type="button" class="btn sm add-btn" onclick="addAuthor(this.closest(\'.card\'))">+ Add author</button>' +
      '<div class="hint">Tick <b>self</b> (you, bold), <b>equal</b> * (equal contribution), <b>corr</b> # (corresponding).</div></div>' +
      '<div class="row"><div class="field"><label>Venue (full)</label><input class="in pub-vfull" placeholder="e.g. IEEE/CVF CVPR"></div>' +
      '<div class="field tight"><label>Venue (short)</label><input class="in pub-vshort" placeholder="CVPR 2026"></div></div>' +
      '<div class="field"><label>Thumbnail</label><div class="img-field"><input type="file" accept="image/*" class="pub-thumb"><img class="thumb" style="display:none"></div></div>' +
      '<div class="row"><div class="field"><label>Paper link</label><input class="in pub-paper" placeholder="https://..."></div>' +
      '<div class="field"><label>Code link</label><input class="in pub-code" placeholder="https://..."></div></div>' +
      '<div class="field"><label>Keywords</label><input class="in pub-kw" placeholder="keyword1; keyword2"></div>';
    const thumbInput = card.querySelector('.pub-thumb');
    thumbInput.onchange = () => pickImage(thumbInput, (ref) => { card.dataset.thumb = ref; });
    card.querySelector('.card-head').appendChild(btn('✕', () => card.remove(), 'danger'));
    list.appendChild(card);
    addAuthor(card);
  }
  function addAuthor(card) {
    const list = card.querySelector('.pub-authors');
    const row = document.createElement('div');
    row.className = 'sub-row';
    row.innerHTML = '<input class="in auth-name" placeholder="Author name">' +
      '<label class="chk"><input type="checkbox" class="auth-self"> self</label>' +
      '<label class="chk"><input type="checkbox" class="auth-equal"> equal *</label>' +
      '<label class="chk"><input type="checkbox" class="auth-corr"> corr #</label>';
    row.appendChild(btn('✕', () => row.remove(), 'danger'));
    list.appendChild(row);
  }

  // ---- collect form -> content.json (unified {groups, items} shape) ----
  function collectDetails(card, sel) {
    return [...card.querySelectorAll((sel || '.edu-details') + ' .sub-row')].map((r) => {
      const text = r.querySelector('.det-text').value.trim();
      const isNote = r.querySelector('.det-note').checked;
      return isNote ? { note: text } : text;
    }).filter((d) => (typeof d === 'string' ? d : d.note));
  }
  function collectAuthors(card) {
    return [...card.querySelectorAll('.pub-authors .sub-row')].map((r) => {
      const a = { name: r.querySelector('.auth-name').value.trim() };
      if (r.querySelector('.auth-self').checked) a.self = true;
      if (r.querySelector('.auth-equal').checked) a.equal = true;
      if (r.querySelector('.auth-corr').checked) a.corresponding = true;
      return a;
    }).filter((a) => a.name);
  }
  function collect() {
    const name = val('p-name');
    const type = val('p-type');
    const bio = [...document.querySelectorAll('#bio-list .bio-text')].map((t) => t.value).filter((v) => v.trim());
    const links = [...document.querySelectorAll('#link-list .sub-row')].map((r) => ({
      label: r.querySelector('.link-label').value.trim(),
      url: r.querySelector('.link-url').value.trim(),
    })).filter((l) => l.label || l.url);
    const news = [...document.querySelectorAll('#news-list .card')].map((c) => ({ date: q(c, '.n-date'), text: q(c, '.n-text') })).filter((n) => n.date || n.text);
    const awards = [...document.querySelectorAll('#award-list .card')].map((c) => ({ date: q(c, '.aw-date'), text: q(c, '.aw-text') })).filter((a) => a.date || a.text);
    const education = [...document.querySelectorAll('#edu-list .card')].map((c) => ({
      logo: c.dataset.logo || '', period: q(c, '.edu-period'), institution: q(c, '.edu-inst'), details: collectDetails(c),
    })).filter((e) => e.institution || e.period || e.details.length);
    const experience = [...document.querySelectorAll('#exp-list .card')].map((c) => ({
      logo: c.dataset.logo || '', period: q(c, '.exp-period'), organization: q(c, '.exp-org'), role: q(c, '.exp-role'),
      details: collectDetails(c, '.exp-details'),
    })).filter((x) => x.organization || x.role || x.period || x.details.length);
    const pubs = { journals: [], conferences: [] };
    [...document.querySelectorAll('#pub-list .card')].forEach((c) => {
      const p = {
        id: q(c, '.pub-id'), title: q(c, '.pub-title'), authors: collectAuthors(c),
        venue_full: q(c, '.pub-vfull'), venue_short: q(c, '.pub-vshort'),
        thumb: c.dataset.thumb || '', preview: c.dataset.thumb || '',
        paper_link: q(c, '.pub-paper'), code_link: q(c, '.pub-code'), keywords: q(c, '.pub-kw'),
      };
      const g = q(c, '.pub-group');
      (pubs[g] || pubs.journals).push(p);
    });
    return {
      meta: { title: (name || 'Member') + "'s Homepage", description: val('p-tagline'), keywords: '', favicon: '', last_updated: '' },
      profile: { name: name || 'Your Name', photo: profilePhotoRef, tagline: val('p-tagline'), bio, email: val('p-email'), links },
      member: { slug: '', type },
      sections: [
        { id: 'education', type: 'education', title: 'Education', enabled: true },
        { id: 'experience', type: 'experience', title: 'Experience', enabled: true },
        { id: 'publications', type: 'publications', title: 'Publications', enabled: true },
        { id: 'awards', type: 'awards', title: 'Awards', enabled: true },
        { id: 'news', type: 'news', title: 'News', enabled: true },
      ],
      news: { groups: [{ key: 'main', label: 'News' }], items: { main: news } },
      education: { groups: [{ key: 'main', label: 'Education' }], items: { main: education } },
      experience: { groups: [{ key: 'main', label: 'Experience' }], items: { main: experience } },
      publications: { groups: [{ key: 'journals', label: 'Journal Papers' }, { key: 'conferences', label: 'Conference Papers' }], items: pubs },
      awards: { groups: [{ key: 'main', label: 'Awards' }], items: { main: awards } },
    };
  }

  // ---- download zip ----
  async function download() {
    const content = collect();
    if (!content.profile.name || content.profile.name === 'Your Name') {
      setStatus('Please enter your name first.', 'err'); return;
    }
    if (typeof JSZip === 'undefined') { setStatus('jszip.min.js failed to load.', 'err'); return; }
    setStatus('Building zip…');
    try {
      const zip = new JSZip();
      zip.file('content.json', JSON.stringify(content, null, 2) + '\n');
      // Bundle every images/... file referenced in the content that we have on hand.
      const refs = new Set();
      (function walk(o) {
        if (o == null) return;
        if (typeof o === 'string') { if (/^images\//.test(o)) refs.add(o); return; }
        if (Array.isArray(o)) { o.forEach(walk); return; }
        if (typeof o === 'object') { Object.values(o).forEach(walk); }
      })(content);
      const imgFolder = zip.folder('images');
      for (const ref of refs) {
        const fname = ref.replace(/^images\//, '');
        if (images[fname]) imgFolder.file(fname, await images[fname].arrayBuffer());
      }
      const blob = await zip.generateAsync({ type: 'blob' });
      const a = document.createElement('a');
      const fname = 'person-' + slugify(content.profile.name) + '.zip';
      a.href = URL.createObjectURL(blob);
      a.download = fname;
      document.body.appendChild(a); a.click(); a.remove();
      setStatus('Downloaded ' + fname + ' - send it to the lab admin to import.', 'ok');
    } catch (e) { setStatus('Failed: ' + (e && e.message ? e.message : e), 'err'); }
  }

  // ---- expose for inline onclick handlers + init ----
  window.addBio = addBio; window.addLink = addLink; window.addNews = addNews; window.addAward = addAward;
  window.addEducation = addEducation; window.addExperience = addExperience; window.addDetail = addDetail; window.addPub = addPub; window.addAuthor = addAuthor;
  window.download = download;
  document.getElementById('p-photo').onchange = function () { pickImage(this, (ref) => { profilePhotoRef = ref; }); };
  // Start with one bio paragraph + one link so the structure is visible.
  addBio(); addLink();
})();
